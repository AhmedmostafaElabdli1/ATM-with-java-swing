package test;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import javaapplication1.Balance;
public class BalanceTest {
    private Balance balance;

    @Before
    public void setUp() {
        balance = new Balance();
    }

    @Test
    public void testGetBalance() {
        int expectedBalance = 1970; // Set the expected balance value
        int actualBalance = balance.getBalance(14); // Provide the account number
        Assert.assertEquals(expectedBalance, actualBalance);
    }
}
