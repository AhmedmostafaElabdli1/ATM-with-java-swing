/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package test;


import javaapplication1.WithDraws;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.api.Assertions;

 /*
 * @author ahmed
 */
public class WithDrawsTest {
    
//    public WithDrawsTest() {
//    }
//    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
    public void testNewBalance() {
              WithDraws w=new WithDraws();

         int oldBalance = 1900;

        int withDrawAmount = 400;
        int expectedNewBalance = 1500;
     
        int actualNewBalance;
        
        actualNewBalance = w.newBalance(oldBalance,withDrawAmount);
        
        Assertions.assertEquals(expectedNewBalance, actualNewBalance);
    }
     
     
     }
