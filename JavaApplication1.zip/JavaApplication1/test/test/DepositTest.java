package test;

import javaapplication1.Deposit;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.jupiter.api.Assertions;

public class DepositTest {
    
    @Test
    public void testNewBalance() {
              Deposit d=new Deposit();

         int oldBalance = 1970;

        int depositAmount = 30;
        int expectedNewBalance = 2000;
     
        int actualNewBalance;
        
        actualNewBalance = d.newBalance(oldBalance,depositAmount);
        
        Assertions.assertEquals(expectedNewBalance, actualNewBalance);
    }
}